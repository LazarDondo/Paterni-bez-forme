/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import concrete_prototype.Frans;
import concrete_prototype.Venecija;
import prototype.Restaurant;

/**
 *
 * @author Lazar
 */
public class Customer {
    Restaurant restaurant;

    public Customer(Restaurant restaurant) {
        this.restaurant = restaurant;
    }
    private void create(){
        restaurant.makeAppetizer();
        restaurant.makeMainDish();
        restaurant.makeDessert();
        restaurant.createOffer();
    }
    
    public static void main(String[] args) {
        Customer customer;
        Frans frans=new Frans();
        customer=new Customer(frans);
        customer.create();
        System.out.println("Restaurant Frans offer: "+frans.getOffer());
        Restaurant fransClone=frans.Clone();
        System.out.println("Restaurant Frans offer (copy): "+fransClone.getOffer());
        
        Venecija venecija=new Venecija();
        customer=new Customer(venecija);
        customer.create();
        System.out.println("Restaurant Venecija offer: "+venecija.getOffer());
        Restaurant venecijaClone=venecija.Clone();
        System.out.println("Restaurant Venecija offer (copy): "+venecijaClone.getOffer());
        
    }
    
}
