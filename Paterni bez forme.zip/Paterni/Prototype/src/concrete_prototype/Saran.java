/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_prototype;

import concrete_product_appetizer.SaranAppetizer;
import concrete_product_dessert.SaranDessert;
import concrete_product_main_dish.SaranMainDish;
import product.Offer;
import prototype.Restaurant;

/**
 *
 * @author Lazar
 */
public class Saran extends Restaurant {

    public Saran() {
        o = new Offer();
    }

    public Saran(Saran saran) {
        o = new Offer();
        o.offer = new String(saran.o.offer);
    }

    @Override
    public void makeAppetizer() {
        appetizer = new SaranAppetizer();
    }

    @Override
    public void makeMainDish() {
        mainDish = new SaranMainDish();
    }

    @Override
    public void makeDessert() {
        dessert = new SaranDessert();
    }

    @Override
    public void createOffer() {
        o.offer = "Appetizer: " + appetizer.getAppetizer() + ", Main dish: " + mainDish.getMainDish() + ", Dessert: " + dessert.getDessert();
    }

    @Override
    public Restaurant Clone() {
       return new Saran(this);
    }

}
