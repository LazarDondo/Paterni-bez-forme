/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_product;

import product.IOffer;

/**
 *
 * @author Lazar
 */
public class Offer implements IOffer{
    public String offer;
    @Override
    public String getOffer() {
        return offer;
    }
    
}
