/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import concrete_creator.Saran;
import concrete_creator.Venecija;
import creator.Restaurant;

/**
 *
 * @author Lazar
 */
public class Customer {
    Restaurant restaurant;

    public Customer(Restaurant restaurant) {
        this.restaurant = restaurant;
    }
    
    private void create(){
        restaurant.create();
    }
    
    public static void main(String[] args) {
        Customer customer;
        
        Saran saran=new Saran();
        customer=new Customer(saran);
        customer.create();
        System.out.println("Restaurant Saran offer: "+saran.getOffer());
        
        Venecija venecija=new Venecija();
        customer=new Customer(venecija);
        customer.create();
        System.out.println("Restaurant Venecija offer: "+venecija.getOffer());
    }
}
