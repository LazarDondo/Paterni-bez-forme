/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_creator;

import concrete_product.Offer;
import concrete_product_appetizer.FransAppetizer;
import concrete_product_dessert.FransDessert;
import concrete_product_main_dish.FransMainDish;
import creator.Restaurant;
import product.IOffer;

/**
 *
 * @author Lazar
 */
public class Frans extends Restaurant{
    
    

    @Override
    public IOffer createOffer() {
        Offer off=new Offer();
        appetizer=new FransAppetizer();
        mainDish=new FransMainDish();
        dessert=new FransDessert();
        off.offer="Appetizer: "+appetizer.getAppetizer()+", Main dish: "+mainDish.getMainDish()+", "+dessert.getDessert();
        return off;
    }
    
}
