/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_flyweight;

import flyweight.Player;

/**
 *
 * @author Lazar
 */
public class CounterTerrorist implements Player{
    // Intrinsic Attribute 
    private final String TASK; 
  
    // Extrinsic Attribute 
    private String weapon; 
  
    public CounterTerrorist() 
    { 
        TASK = "DIFFUSE BOMB"; 
    } 
    @Override
    public void assignWeapon(String weapon) 
    { 
        this.weapon = weapon; 
    } 
    @Override
    public void mission() 
    { 
        System.out.println("Counter Terrorist with weapon "
                           + weapon + "|" + " Task is " + TASK); 
    } 
}
