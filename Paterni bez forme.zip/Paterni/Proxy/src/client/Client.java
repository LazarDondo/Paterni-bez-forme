/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import proxy.HiringManager;
import subject.Employee;

/**
 *
 * @author Lazar
 */
public class Client {
    public static void main(String[] args) {
        Employee employee=new HiringManager();
        try {
            employee.hire("dddd");
            employee.hire("aaa"); 
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
