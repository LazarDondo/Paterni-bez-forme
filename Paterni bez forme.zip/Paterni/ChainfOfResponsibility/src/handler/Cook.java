/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package handler;

/**
 *
 * @author Lazar
 */
public abstract class Cook {
    public static int HEADCHEFLEVEL=3;
    public static int SOUSCHEFLEVEL=2;
    public static int ASSISTANTCOOKLEVEL=1;
    
    protected int level;
    
    protected Cook nextCook;

    public void setNextCook(Cook nextCook){
      this.nextCook = nextCook;
   }

   public void delegate(int level){
      if(this.level <= level){
         write();
      }
      if(nextCook !=null){
         nextCook.delegate(level);
      }
   }
   
   abstract protected void write();
    
}
