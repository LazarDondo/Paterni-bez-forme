/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import adapter.AnimalAdapter;
import concrete_adaptee.Bird;
import concrete_adaptee.Dog;
import target.AnimalTarget;

/**
 *
 * @author Lazar
 */
public class Client {
    AnimalTarget animalTarget;

    public Client(AnimalTarget animalTarget) {
        this.animalTarget = animalTarget;
    }
    
    void function(){
        animalTarget.animalSound();
        animalTarget.animalMovement();
    }
    
    public static void main(String[] args) {
        Client client;
        AnimalTarget animalTarget;
        Bird bird=new Bird();
        
        
        Dog dog=new Dog();
        animalTarget=new AnimalAdapter(dog);
        client=new Client(animalTarget);
        client.function();
        
    }
}
