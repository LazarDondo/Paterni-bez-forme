/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import concrete_state.AssistantCook;
import concrete_state.HeadChef;
import concrete_state.SousChef;
import context.Context;

/**
 *
 * @author Lazar
 */
public class Client {
    public static void main(String[] args) {
        Context context=new Context();
        context.getCook().currentState();
        
        SousChef sousChef=new SousChef();
        context.setCook(sousChef);
        context.getCook().currentState();
        
        AssistantCook assistantCook=new AssistantCook();
        assistantCook.makeDish(context);
        context.getCook().currentState();
        
    }
}
