    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_state;

import context.Context;
import state.Cook;

/**
 *
 * @author Lazar
 */
public class HeadChef implements Cook{

    @Override
    public void makeDish(Context context) {
        currentState();
        context.setCook(this);
    }

    @Override
    public void currentState() {
        System.out.println("Head chef is preparing main dish.");
    }
    
    
    
}
