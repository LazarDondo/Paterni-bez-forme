/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package context;

import concrete_state.HeadChef;
import state.Cook;

/**
 *
 * @author Lazar
 */
public class Context {
    private Cook cook;

    public Context() {
        cook=new HeadChef();
    }
    
    public void setCook(Cook cook){
        this.cook=cook;
    }
    
    public Cook getCook(){
        return cook;
    }
    
    
}
