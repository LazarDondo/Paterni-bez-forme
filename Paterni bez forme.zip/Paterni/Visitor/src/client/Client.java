/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import concrete_element.Book;
import concrete_element.Fruit;
import concrete_visitor.ShoppingCartVisitorImpl;
import element.ItemElement;
import visitor.ShoppingCartVisitor;

/**
 *
 * @author Lazar
 */
public class Client {
    public static void main(String[] args)  
    { 
        ItemElement[] items = new ItemElement[]{new Book(20, "1234"), 
                              new Book(100, "5678"), new Fruit(10, 2, "Banana"), 
                              new Fruit(5, 5, "Apple")}; 
   
        int total = calculatePrice(items); 
        System.out.println("Total Cost = "+total); 
    } 
   
    private static int calculatePrice(ItemElement[] items)  
    { 
        ShoppingCartVisitor visitor = new ShoppingCartVisitorImpl(); 
        int sum=0; 
        for(ItemElement item : items) 
        { 
            sum = sum + item.accept(visitor); 
        } 
        return sum; 
    } 
}
