/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visitor;

import concrete_element.Book;
import concrete_element.Fruit;

/**
 *
 * @author Lazar
 */
public interface ShoppingCartVisitor {

    int visit(Book book);

    int visit(Fruit fruit);
}
