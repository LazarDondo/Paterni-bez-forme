/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import composite.HeadChef;
import leaf.AssistantCook;
import leaf.SousChef;

/**
 *
 * @author Lazar
 */
public class Client {
    public static void main(String[] args) {
        SousChef sousChefOne=new SousChef(1, "aaa");
        SousChef sousChefTwo=new SousChef(2, "bbb");
        AssistantCook assistantCook=new AssistantCook(3, "ccc");
        HeadChef headChef=new HeadChef(); 
        headChef.addCook(sousChefOne);
        headChef.addCook(sousChefTwo);
        headChef.addCook(assistantCook);
        headChef.showDetails();
    }
}
