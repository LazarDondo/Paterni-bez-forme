/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package leaf;

import component.Cook;

/**
 *
 * @author Lazar
 */
public class SousChef implements Cook{
     private int cookId;
    private String name;

    public SousChef(int cookId, String name) {
        this.cookId = cookId;
        this.name = name;
    }
    
    
    @Override
    public void showDetails() {
        System.out.println(cookId + " " + name + " is sous chef.");
    }
}
