/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package composite;

import component.Cook;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Lazar
 */
public class HeadChef implements Cook{

    private List<Cook> cookList=new ArrayList<Cook>();
    
    
    @Override
    public void showDetails() {
        for (Cook cook : cookList) {
            cook.showDetails();
        }
    }
    
    public void addCook(Cook cook){
        cookList.add(cook);
    }
    
    public void removeCook(Cook cook){
        cookList.remove(cook);
    }
    
    
    
}
