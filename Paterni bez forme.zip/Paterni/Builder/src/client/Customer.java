/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import builder.Restaurant;
import concrete_builder.Frans;

/**
 *
 * @author Lazar
 */
public class Customer {
    Restaurant restaurant;

    private Customer(Restaurant restaurant) {
        this.restaurant = restaurant;
    }
    
    private void makeOffer(){
        restaurant.makeAppetizer();
        restaurant.makeMainDish();
        restaurant.makeDessert();
        restaurant.createOffer();
    }
    
    public static void main(String[] args) {
        Customer client;
        Frans frans=new Frans();
        client=new Customer(frans);
        client.makeOffer();
        System.out.println(frans.getOffer());
    }
}
