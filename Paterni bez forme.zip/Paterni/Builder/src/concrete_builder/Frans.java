/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_builder;

import builder.Restaurant;
import concrete_product_appetizer.FransAppetizer;
import concrete_product_dessert.FransDessert;
import concrete_product_main_dish.FransMainDish;
import product.Offer;

/**
 *
 * @author Lazar
 */
public class Frans extends Restaurant {

    public Frans() {
        o = new Offer();
    }
    
    

    @Override
    public void makeAppetizer() {
        appetizer = new FransAppetizer();
    }

    @Override
    public void makeMainDish() {
        mainDish = new FransMainDish();
    }

    @Override
    public void makeDessert() {
        dessert = new FransDessert();
    }

    @Override
    public void createOffer() {
        o.offer = "Restauran Frans offer: Appetizer: " + appetizer.getAppetizer() + ", Main dish: " + mainDish.getMainDish() + ", Dessert: " + dessert.getDessert();
    }

    

}
