/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package builder;

import product.Offer;
import abstract_product.Appetizer;
import abstract_product.Dessert;
import abstract_product.MainDish;

/**
 *
 * @author Lazar
 */
public abstract class Restaurant {
    public Offer o;
    public Appetizer appetizer;
    public MainDish mainDish;
    protected Dessert dessert;
    
    public abstract void makeAppetizer();
    public  abstract void makeMainDish();
    public abstract void makeDessert();
    public abstract void createOffer();
    public  String getOffer(){
        return o.offer;
    }
}
