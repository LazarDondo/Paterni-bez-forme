/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_factory;

import abstract_factory.Restaurant;
import abstract_product.Appetizer;
import abstract_product.Dessert;
import abstract_product.MainDish;
import concrete_product_appetizer.VenecijaAppetizer;
import concrete_product_dessert.VenecijaDessert;
import concrete_product_main_dish.VenecijaMainDish;

/**
 *
 * @author Lazar
 */
public class Venecija implements Restaurant{

    @Override
    public Appetizer makeAppetizer() {
        return new VenecijaAppetizer();
    }

    @Override
    public MainDish makeMainDish() {
        return new VenecijaMainDish();
    }

    @Override
    public Dessert makeDessert() {
       return new VenecijaDessert();
    }
    
}
