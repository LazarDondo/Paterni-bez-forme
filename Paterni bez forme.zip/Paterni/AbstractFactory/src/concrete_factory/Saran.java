/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_factory;

import abstract_factory.Restaurant;
import abstract_product.Appetizer;
import abstract_product.Dessert;
import abstract_product.MainDish;
import concrete_product_appetizer.SaranAppetizer;
import concrete_product_dessert.SaranDessert;
import concrete_product_main_dish.SaranMainDish;

/**
 *
 * @author Lazar
 */
public class Saran implements Restaurant {

    @Override
    public Appetizer makeAppetizer() {
        return new SaranAppetizer();
    }

    @Override
    public MainDish makeMainDish() {
        return new SaranMainDish();
    }

    @Override
    public Dessert makeDessert() {
        return new SaranDessert();
    }

}
