/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import abstract_factory.Restaurant;
import abstract_product.Appetizer;
import abstract_product.Dessert;
import abstract_product.MainDish;
import concrete_factory.Saran;
import concrete_factory.Venecija;

/**
 *
 * @author Lazar
 */
public class Customer {

    Restaurant restaurant;
    Appetizer appetizer;
    MainDish mainDish;
    Dessert dessert;
    Offer o;

    public Customer(Restaurant restaurant) {
        this.restaurant = restaurant;
        o = new Offer();
    }

    public static void main(String[] args) {
        Customer customer;
        Venecija venecija = new Venecija();
        customer = new Customer(venecija);
        System.out.println("Venecija restaurant offer: " + customer.kreiraj());

        Saran saran = new Saran();
        customer = new Customer(saran);
        System.out.println("Saran restaurant offer: " + customer.kreiraj());
    }

    private String kreiraj() {
        appetizer = restaurant.makeAppetizer();
        mainDish = restaurant.makeMainDish();
        dessert = restaurant.makeDessert();
        o.offer = "Appetizer: " + appetizer.getAppetizer() + ", Main dish: " + mainDish.getMainDish() + ", Dessert: " + dessert.getDessert()+'.';
        return o.offer;
    }

}
