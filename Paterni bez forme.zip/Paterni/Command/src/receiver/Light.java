/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package receiver;

/**
 *
 * @author Lazar
 */
public class Light {
    public void on() 
    { 
        System.out.println("Light is on"); 
    } 
    public void off() 
    { 
        System.out.println("Light is off"); 
    } 
}
