/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package memento;

/**
 *
 * @author Lazar
 */
public class Memento {
    private final String name; 
   
        public Memento(String nameToSave)  
        { 
            name = nameToSave; 
        } 
   
        public String getSavedCook()  
        { 
            return name; 
        } 
}
