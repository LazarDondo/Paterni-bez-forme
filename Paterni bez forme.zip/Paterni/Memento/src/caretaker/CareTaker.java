/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package caretaker;

import java.util.ArrayList;
import java.util.List;
import memento.Memento;
import originator.Cook;

/**
 *
 * @author Lazar
 */
public class CareTaker {
    public static void main(String[] args)  
    { 
          
        List<Memento> savedCooks = new ArrayList<Memento>(); 
   
        Cook cook = new Cook(); 
   
        //time travel and record the eras 
        cook.set("Gordon Ramsay"); 
        savedCooks.add(cook.saveToMemento()); 
        cook.set("Guy Fieri"); 
        savedCooks.add(cook.saveToMemento()); 
        cook.set("JJ Johnson"); 
        savedCooks.add(cook.saveToMemento()); 
        cook.set("Bobby Flay"); 
   
        cook.restoreFromMemento(savedCooks.get(0));    
   
    } 
}
