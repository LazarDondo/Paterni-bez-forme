/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package originator;

import memento.Memento;

/**
 *
 * @author Lazar
 */
public class Cook {
    private String name; 
   
    public void set(String name)  
    { 
        System.out.println("Setting name to: " + name); 
        this.name = name; 
    } 
   
    public Memento saveToMemento()  
    { 
        System.out.println("Saving cook to Memento."); 
        return new Memento(name); 
    } 
   
    public void restoreFromMemento(Memento memento)  
    { 
        name = memento.getSavedCook(); 
        System.out.println("Cook restored from Memento: " + name); 
    } 
}
