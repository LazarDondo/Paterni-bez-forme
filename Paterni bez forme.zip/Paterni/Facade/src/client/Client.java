/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import facade.RestaurantManager;

/**
 *
 * @author Lazar
 */
public class Client {
    public static void main(String[] args) {
        RestaurantManager restaurantManager=new RestaurantManager();
        restaurantManager.assignHeadChef();
        restaurantManager.assignSousChef();
        restaurantManager.assignAssitantCook();
    }
}
