/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sybsystem_classes;

/**
 *
 * @author Lazar
 */
public class HeadChef implements Cook{

    @Override
    public void details() {
        System.out.println("Head chef");
    }
    
}
