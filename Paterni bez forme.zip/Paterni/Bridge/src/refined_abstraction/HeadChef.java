/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package refined_abstraction;

import abstraction.Cook;
import implementor.Dish;

/**
 *
 * @author Lazar
 */
public class HeadChef extends Cook{

    public HeadChef(Dish appetizer, Dish mainDish, Dish desert) {
        super(appetizer, mainDish, desert);
    }

    @Override
    public void makeDish() {
        System.out.println("Head chef");
        appetizer.cook();
        mainDish.cook();
        desert.cook();
    }
    
}
