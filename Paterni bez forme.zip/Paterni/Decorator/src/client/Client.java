/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;

import component.Cook;
import concrete_component.HeadChef;
import concrete_component.SousChef;
import concrete_decorator.CookDecoratorOne;
import concrete_decorator.CookDecoratorTwo;

/**
 *
 * @author Lazar
 */
public class Client {
    public static void main(String[] args) {
        Cook cookOne=new HeadChef();
        System.out.println(cookOne.getDetails()+" Position: "+cookOne.getPosition());
        
        Cook cookTwo=new SousChef();
        System.out.println(cookTwo.getDetails()+" Position: "+cookTwo.getPosition());
        cookTwo=new CookDecoratorTwo(cookTwo);
        System.out.println(cookTwo.getDetails()+" Position: "+cookTwo.getPosition());
       
    }
}
