/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstract_class;

/**
 *
 * @author Lazar
 */
public abstract class Cook {

    public final void makeThreeCourseMeal() {
        makeAppetizer();
        makeMainDish();
        makeDessert();

    }

    protected abstract void makeAppetizer();

    protected abstract void makeMainDish();

    protected abstract void makeDessert();
}
