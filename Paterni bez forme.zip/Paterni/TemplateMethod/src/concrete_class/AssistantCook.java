/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concrete_class;

import abstract_class.Cook;

/**
 *
 * @author Lazar
 */
public class AssistantCook extends Cook{

    @Override
    protected void makeAppetizer() {
        System.out.println("Assisant cook's appetizer.");
    }

    @Override
    protected void makeMainDish() {
        System.out.println("Assisant cook's main dish.");
    }

    @Override
    protected void makeDessert() {
        System.out.println("Assisant cook's dessert.");
    }
    
}
